<template>
	<demo-page></demo-page>
</template>

<script>
	import demoPage from '../demo/demo.vue'
	export default {
		components: {
			demoPage
		}
	}
</script>
