
let kToast = "jj_toast"
let kAlert = 'jj_alert'
let kLoading = 'jj_loading'

export {
	kToast,
	kAlert,
	kLoading,
}