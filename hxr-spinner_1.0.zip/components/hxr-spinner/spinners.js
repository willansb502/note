const spinkitSpinners = {
  'circle': { className: 'sk-circle', divCount: 12 },
  'cube-grid': { className: 'sk-cube-grid', divCount: 9 },
  'wave': { className: 'sk-wave', divCount: 5 },
  'folding-cube': { className: 'sk-folding-cube', divCount: 4 },
  'three-bounce': { className: 'sk-three-bounce', divCount: 3 },
  'double-bounce': { className: 'sk-double-bounce', divCount: 2 },
  'wandering-cubes': { className: 'sk-wandering-cubes', divCount: 2 },
  'chasing-dots': { className: 'sk-chasing-dots', divCount: 2 },
  'rotating-plane': { className: 'sk-rotating-plane', divCount: 1 },
  'pulse': { className: 'sk-pulse', divCount: 1 },
  'wordpress': { className: 'sk-wordpress', divCount: 1 },
  'fading-circle': { className: 'sk-fading-circle', divCount: 12 }
}

const loadersCssSpinners = {
  'square-spin': { divCount: 1 },
  'ball-grid-beat': { divCount: 9 },
  'ball-grid-pulse': { divCount: 9 },
  'line-spin-fade-loader': { divCount: 8 },
  'ball-spin-fade-loader': { divCount: 8 },
  'ball-pulse-rise': { divCount: 5 },
  'line-scale': { divCount: 5 },
  'line-scale-pulse-out': { divCount: 5 },
  'line-scale-pulse-out-rapid': { divCount: 5 },
  'pacman': { divCount: 5 },
  'line-scale-party': { divCount: 4 },
  'ball-triangle-path': { divCount: 3 },
  'ball-scale-multiple': { divCount: 3 },
  'ball-scale-ripple-multiple': { divCount: 3 },
  'ball-pulse-sync': { divCount: 3 },
  'ball-pulse': { divCount: 3 },
  'ball-beat': { divCount: 3 },
  'ball-zig-zag': { divCount: 2 },
  'ball-zig-zag-deflect': { divCount: 2 },
  'ball-clip-rotate-pulse': { divCount: 2 },
  'ball-clip-rotate-multiple': { divCount: 2 },
  'ball-clip-rotate': { divCount: 1 },
  'ball-scale-ripple': { divCount: 1 },
  'triangle-skew-spin': { divCount: 1 }
}

const loadingIOSpinners = {
  'circle-solid-spin': { className: 'sk-circle-solid-spin', divCount: 1 },
  'dual-ring': { className: 'sk-dual-ring', divCount: 0 },
  'facebook': { className: 'sk-facebook', divCount: 3 },
  'heart': { className: 'sk-heart', divCount: 1 },
  'ring': { className: 'sk-ring', divCount: 4 },
  'roller': { className: 'sk-roller', divCount: 8 },
  'ellipsis': { className: 'sk-ellipsis', divCount: 4 },
  'grid': { className: 'sk-grid', divCount: 9 },
  'hourglass': { className: 'sk-hourglass', divCount: 0 },
  'ripple': { className: 'sk-ripple', divCount: 2 }
}

const awesomeSpinners = {
  'loadbar': { className: 'sk-loadbar', divCount: 0 },
  'hydrogen': { className: 'sk-hydrogen', divCount: 0 },
  'clock': { className: 'sk-clock', divCount: 0 },
  'circle-fade': { className: 'sk-circle-fade', divCount: 0 },
  'moon': { className: 'sk-moon', divCount: 1 }
}

export default {
  spinkitSpinners,
  loadersCssSpinners,
  loadingIOSpinners,
  awesomeSpinners,
  allSpinners: {
    ...spinkitSpinners,
    ...loadersCssSpinners,
    ...loadingIOSpinners,
    ...awesomeSpinners
  }
}
